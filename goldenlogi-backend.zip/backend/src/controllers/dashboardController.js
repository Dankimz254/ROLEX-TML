export const getStats = async (req, res) => {
  try {
    return res.json({
      revenue: 25000,
      shipments: 180,
      clients: 34,
      successRate: "97%"
    });
  } catch (err) {
    res.status(500).json({ message: 'Server Error' });
  }
};
